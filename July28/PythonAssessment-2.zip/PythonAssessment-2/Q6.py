import json
file=open("inventory.json","r")
data=json.load(file)
file.close()
for item in data:
    if item["stock"]>0:
        item["status"]="In-Stock"
    else:
        item["status"]="Out of Stock"
file=open("inventory_updated.json","w")
json.dump(data,file)
file.close()
print("inventory_updated.json created")
