import numpy as np
import pandas as pd
scores=np.random.randint(35,101,20)
count=0
for score in scores:
    if score > 75:
        count=count+1
mean=scores.mean()
std=scores.std()
print("scores:",scores)
print("Above 75:",count)
print("Mean:",mean)
print("Standard deviation",std)
df=pd.DataFrame({"Scores":scores})
df.to_csv("scores.csv",index=False)