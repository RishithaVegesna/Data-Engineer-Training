students = [("Aarav", 80), ("Sanya", 65), ("Meera", 92), ("Rohan", 55)]
for student in students:
    name = student[0]
    score = student[1]
    if score > 75:
        print(name)
total=0
for student in students:
    total=total+student[1]
average=total/len(students)
print("Average score:",average)