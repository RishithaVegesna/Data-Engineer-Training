import pandas as pd

df = pd.read_csv("students_cleaned.csv")
status_list = []
for score in df['Score']:
    if score >= 85:
        status_list.append("Distinction")
    elif score >= 60:
        status_list.append("Passed")
    else:
        status_list.append("Failed")

df['Status'] = status_list

tax_ids = []
for id_value in df['ID']:
    tax_ids.append("TAX-" + str(id_value))

df['Tax_ID'] = tax_ids
df.to_csv("students_transformed.csv", index=False)
print("Q8 complete: students_transformed.csv created.")

