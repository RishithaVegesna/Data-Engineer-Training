def process_numbers(lst):
    unique = list(set(lst))
    unique.sort()
    print("Sorted Unique:", unique)
    if len(unique) >= 2:
        print("Second Largest:", unique[-2])
    else:
        print("Not enough elements")
process_numbers([4, 2, 7, 2, 5, 7])
