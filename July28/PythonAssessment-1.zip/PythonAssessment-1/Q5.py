class Vehicle:
    def drive(self):
        print("Vehicle is driving")
class Car(Vehicle):
    def drive(self):
        print("Car is driving smoothly")
c=Car()
c.drive()
