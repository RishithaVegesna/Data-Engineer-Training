import pandas as pd
df=pd.read_csv("students_cleaned.csv")
df.to_json("students.json")
print("students.json file created")