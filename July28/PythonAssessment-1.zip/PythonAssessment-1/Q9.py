import json
file = open("products.json", "r")
data = json.load(file)
file.close()
for item in data:
    item["price"] = item["price"] * 1.1
file = open("products_updated.json", "w")
json.dump(data, file)
file.close()

print("products_updated.json file created.")

