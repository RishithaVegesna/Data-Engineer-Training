def check_palindrome():
    s=input("Enter a string:")
    reversed_s=s[::-1]
    print("Reversed:",reversed_s)
    if s==reversed_s:
        print("It is palindrome")
    else:
        print("Not a palindrome")
check_palindrome()
