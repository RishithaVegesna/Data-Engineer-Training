class person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print("Name:",self.name)
        print("Age:",self.age)
class Employee(person):
    def __init__(self,name,age,employee_id,department):
        super().__init__(name,age)
        self.employee_id=employee_id
        self.department=department
    def display(self):
        super().display()
        print("Employee ID",self.employee_id)
        print("Department:",self.department)
emp=Employee("Rishitha",22,"101","Engineering")
emp.display()